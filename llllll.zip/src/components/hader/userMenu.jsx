import React from 'react'

const UserMenu = () => {
  return (
    <div className="user-menu">
    <button>פרטי משתמש</button> <br />
    <button >התנתקות</button>
  </div>
  )
}

export default UserMenu