import React from 'react'

const Logo = () => {
  return (
    <div className='d-flex justify-content-center '>
      <div >
          <img style={{height:"120px",width:"500px"}} src="https://i.imagesup.co/images2/e7c930c69770f2da1d60d9c09b0e69a5efbe2c14.png" alt="logo" />
      </div>
    </div>
  )
}

export default Logo